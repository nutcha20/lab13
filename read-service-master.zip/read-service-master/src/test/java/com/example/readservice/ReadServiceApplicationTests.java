package com.example.readservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ReadServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
