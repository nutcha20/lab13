package com.example.bookstoreservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookstoreServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
